#include <iostream>
#include <iomanip>
#include <string>
#include <vector>
#include <iostream>
#include <algorithm>
using namespace std;
//FIXES
//fixes fnal ouput when n is used.
//add callback functionality if questions are nanswered*
//add unaswered parameter in script*
//to check if it is more than to words that is inserted*
//when an answer is entered in prev() should continue as scheduled*
//check if new word has replaced old word in prev()*
//check if the next question has been answered else return main()*
//alert user of questions that haven't been answered
/*Fixing this would require me to rework my code from the foundation there simply no time for that*/
/*easier that anticipated*/
void quizgame(int tracker);
void prev(int t);
void spec_prev(int t);
void next(int n);
void finish();
void script();
int points=0;
string buffer(' ',1);
vector<vector<string>> que{
        {"S/N","1","2","3","4","5","6","7","8","9","10"},
        {"Question","Whih of the following is the correct identifier?","Which of the following is the address operator?","Which of the following features must be supported by any programming language to become a pure object-oriented programming language?","Which of the following refers to characteristics of an array?","If we stored five elements or data items in an array, what will be the index address or the index number of the array\"s last data item?","Which of the following is the correct syntax for declaring the array?","Which of the following is the correct syntax for accessing the first element?","Which of the following gives the 4th element of the array?","Which type of memory is used by an Array in C++ programming language?","Which one of the following is the correct definition of the \"is_array();\" function in C++?"},
        {"A","$var_name","@","Encapsulation","An array is a set of similar data items","2","int array{};","array[2];","array[2];","Contiguous","It checks that the specified variable is of the array or not"},
        {"B","VAR_123","#","Inheritance","An array is a set of distinct data items","3","int array [5];","array[0]","array[3]","None-contiguous","It checks that the specified array of single dimension or not"},
        {"C","varname@","&","Polymorphism","An array can hold different types of data types","4","Array[5];","Array[5];","Array[5];","Both A and B","It checks that the array specified of multi-dimension or not"},
        {"D","None of the above","%","All of the above","None of the above","5","None of the above","array[1]","array[1]","Not mentioned","Both B and C"},
        {"Answer","B","C","D","A","C","B","B","B","A","A"}
    };
vector<string> options{"A","B","C","D"};
vector<string> answer;
int tracker=1;
string nl="-";

main(){
    int init;
   cout<<"                  Welcome to C++ quiz game\n";
   cout<<"                  ------------------------\n";
   cout<<"Press 1 to Start\n";
   cout<<"Press 2 to Exit\n";
   do{
    cin>>init;
    if(init==1){
            cout<<"             Rules of the game\n";
    cout<<"             ------------------\n";
    cout<<"You are expected to answer 10 questions\n";
    cout<<"You can skip a question and return to it later\n";
    cout<<"To answer a question enter the right option on the keyboard and press Enter\n";
    cout<<"To skip a question Press N\n";
    cout<<"To go back to previous Press P\n";
    cout<<"To submit Press F\n";
        quizgame(tracker);
    }else if(init==2){
        exit(1);
    }else{
        cout<<"You enetered a wrong value";
   }
   }while(true);

}

void quizgame(int tracker){



    do{
        cout<<"Question "<<que[0][tracker]<<"\n";
        cout<<que[1][tracker]<<"\n";
        cout<<"A. "<<que[2][tracker]<<" ";
        cout<<"B.  "<<que[3][tracker]<<"\n";
        cout<<"C.  "<<que[4][tracker]<<" ";
        cout<<"D.  "<<que[5][tracker]<<"\n";
        cout<<"Enter your Answer ";
        cin>>buffer;
        //lowercase check and conversion*
        //n to skip*
        //p go to previous*
        //check if he inputted a,b
        if(buffer.size()==1){
            if(isupper(buffer[0])){
            
        }else{
            buffer[0]-=32;
        }
        }else{
            cout<<"That isn't a valid answer";
            exit(1);
        }
        if(buffer[0] >= 'A' && buffer[0] <= 'D'){
                answer.insert(answer.begin()+(tracker-1),buffer);
        }else if(buffer=="N"){
            if(tracker!=10){
                answer.insert(answer.begin()+(tracker-1),nl);
                next(stoi(que[0][tracker]));  
            }          
        }else if(buffer=="P"){
            prev(tracker);
            tracker--;
        }else{
            cout<<"That isn't a valid operation";
            exit(1);
        }
        tracker++;
    }while(tracker!=11);
    do{
        cout<<"\n";
    cout<<"This is the last question\n";
    cout<<"Press F to submit\n";
    cout<<"Press P to go back to the previous question\n";
    cout<<"Enter your answer\n";
    cin>>buffer;
    if(isupper(buffer[0])){

    }else{
        buffer[0]-=32;
        }
    if(buffer == "P"){
        prev(tracker);
    }else if(buffer=="F"){
        finish();
        }
    }while(true);

}

void prev(int t){
        if(answer.size()>=t-1 && t!=1){
              if(t-1 != 1){
                  cout<<"Previous Question \n"; 
                  cout<<"Question "<<que[0][t-1]<<"\n";
                  cout<<que[1][t-1]<<"\n";
                  cout<<"A. "<<que[2][t-1]<<" ";
                  cout<<"B.  "<<que[3][t-1]<<"\n";
                  cout<<"C.  "<<que[4][t-1]<<" ";
                  cout<<"D.  "<<que[5][t-1]<<"\n";
                  cout<<"You selected "<<answer.at(t-2)<<"\n";
                  cout<<"Enter your Answer ";
                  cin>>buffer;
                  if(isupper(buffer[0])){

                  }else{
                      buffer[0]-=32;
            }
        if(buffer[0] >= 'A' && buffer[0] <= 'D'){
            answer.insert(answer.begin()+(stoi(que[0][t-1])-1),buffer);
            //quizgame(t+1);
        }else if(buffer=="P"){
            prev(stoi(que[0][t-1]));
            
        }else if(buffer=="N"){
                next(stoi(que[0][t-1]));
        }else{
            cout<<"This parameter can't be satisfied";
        }

    
        
    }else{
        cout<<"This is the first question\n";
        cout<<"Question "<<que[0][t-1]<<"\n";
                  cout<<que[1][t-1]<<"\n";
                  cout<<"A. "<<que[2][t-1]<<" ";
                  cout<<"B.  "<<que[3][t-1]<<"\n";
                  cout<<"C.  "<<que[4][t-1]<<" ";
                  cout<<"D.  "<<que[5][t-1]<<"\n";
                  cout<<"You selected "<<answer.at(t-2)<<"\n";
                  cout<<"Enter your Answer ";
                  cin>>buffer;
                  if(isupper(buffer[0])){

                  }else{
                      buffer[0]-=32;
            }
        if(buffer[0] >= 'A' && buffer[0] <= 'D'){
            answer.insert(answer.begin()+(stoi(que[0][t-1])-1),buffer);
            //quizgame(t+1);
        }else if(buffer=="P"){
            cout<<"That was the first question";
            exit(1);
            
        }else if(buffer=="N"){
                next(stoi(que[0][t-1]));
        }else{
            cout<<"This parameter can't be satisfied";
        }

        } 
        }else if(t==1){
            cout<<"This is the first question.\n";
        }else{
            quizgame(t-1);
        }
    }
    


void next(int n){
    //check if new word has replaced old word in prev()* and next()*
    //check if the next question has been answered else return main()*
    //check if prev() works and next() works*
    
    if(answer.size()>=n+1){
        
               if(n != 10){
                cout<<"Next question \n"; 
                cout<<"Question "<<que[0][n+1]<<"\n";
                cout<<que[1][n+1]<<"\n";
                cout<<"A. "<<que[2][n+1]<<" ";
                cout<<"B.  "<<que[3][n+1]<<"\n";
                cout<<"C.  "<<que[4][n+1]<<" ";
                cout<<"D.  "<<que[5][n+1]<<"\n";
        cout<<"You selected "<<answer.at(stoi(que[0][n]))<<"\n";
        cout<<"Enter your Answer ";
        cin>>buffer;
        if(isupper(buffer[0])){

        }else{
            buffer[0]-=32;
            }
        if(buffer[0] >= 'A' && buffer[0] <= 'D'){
            answer.insert(answer.begin()+(stoi(que[0][n])),buffer);
        }else if(buffer=="P"){
            prev(stoi(que[0][n]));
        }else if(buffer=="N"){
            next(stoi(que[0][n+1]));
        }else{
            cout<<"This parameter can't be satisfied";
        }
        }else{
            cout<<"This is the last question";
                
    }
}else{
        quizgame(n+1);
    }
}
    
     
    

    


void finish(){
    cout<<"processing...\n";
    if(answer.empty()==false){
            for(int i=1;i<11;i++){
                if(answer.at(i-1)==que[6][i]){
                    points++;
}
    }
    }else{
    cout<<"you scored 0 out of 10\n";
    cout<<"You won't make it in life like this.\n";
    cout<<"To view your scirpt Press V\n";
    cin>>buffer;
    if(isupper(buffer[0])){

    }else{
        buffer[0]-=32;
        }
    if(buffer == "V"){
        script();
    }else{
        cout<<"That isn't a valid parameter";
    }
    }

    cout<<"you scored "<<points<<" out of 10\n";
    cout<<"To view your scirpt Press V\n";
    cin>>buffer;
    if(isupper(buffer[0])){

    }else{
        buffer[0]-=32;
        }
    if(buffer == "V"){
        script();
    }else{
        cout<<"That isn't a valid parameter";
    }
}
void script(){
    cout<<"---------------------------------------------------------------------------------------------------\n";
    for(int i=0;i<10;i++){
        
            cout<<"Question "<<que[0][i+1]<<"\n";
            cout<<que[1][i+1]<<"\n";
            cout<<"A. "<<que[2][i+1]<<" ";
            cout<<"B.  "<<que[3][i+1]<<"\n";
            cout<<"C.  "<<que[4][i+1]<<" ";
            cout<<"D.  "<<que[5][i+1]<<"\n";
            cout<<"Correct Option: "<<que[6][i+1]<<"       ";
            cout<<"Your Choice: "<<answer[i]<<"     ";
            if(que[6][i+1]==answer[i]){
                cout<<"Correct!\n";
                cout<<"\n";
            
            }else if(answer[i]==nl){
                cout<<"Unanswered!\n";
                cout<<"\n";

            }else{
                cout<<"Wrong!\n";
                cout<<"\n";
            }
        
    }
    cout<<"----------------------------------------------------------------------------------------------------\n";
    exit(1);

}